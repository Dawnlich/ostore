<?php 
session_start();
include "database.php";?>
<!DOCTYPE html> 
<html>
<head>
    <title> Sign up page</title>
    <link rel="stylesheet" type="text/css" href="signup.css">
    <script>
        function myFunction(){
            var checkBox = document.getElementById("myCheck");
            var checkBox2 = document.getElementById("myCheck2");
            var text = document.getElementById("text");
            var text2 = document.getElementById("text2");
            if (checkBox.checked == true){
                text.style.display = "block";
                text2.style.display = "none";
            }else if(checkBox2.checked == true){
                text2.style.display = "block";
                text.style.display = "none";
            }
        }
    </script>
</head>
<body>
    <form method="post">
        <h2>Sign up</h2>
        <label for="email"><b>Please Enter Email:</b></label>
        <input type="text" placeholder="Enter Email" name="email" required>
        <label for="fname"><b>Please Enter first Name:</b></label>
        <input type="text" placeholder="Enter first Name" name="fname" required>
        <label for="lname"><b>Please Enter last Name:</b></label>
        <input type="text" placeholder="Enter last Name" name="lname" required>
        <label for="uname"><b>Please Enter a Username:</b></label>
        <input type="text" placeholder="Enter Username" name="username" required>
        <label for="psw"><b>Please Enter a Password (8 characters long):</b></label>
        <input type="password" placeholder="Enter Password" name="psw" required>
        <label for="psw-repeat"><b>Please Repeat Password (8 characters long):</b></label>
        <input type="password" placeholder="Repeat Password" name="psw-repeat" required>
        <input type="radio" name="check" value="nc" id="myCheck" onclick="myFunction()">New Company
        <input type="text" id="text" style = "display:none" placeholder="Company's name...." name="companyName">
        <br></br>
        <input type="radio" name="check" value="ce" id="myCheck2" onclick="myFunction()">Current Employee
        <input type="text" id="text2" style = "display:none" placeholder="Company's code...." name="companyCode">
        <br></br>
        <input type="submit" name="signup" value="Sign-up"> 
    </form>
    <?php

        error_reporting(E_ERROR | E_PARSE);

        //variables
        $email = $_POST['email'];
        $fname = $_POST['fname'];
        $lname = $_POST['lname']; 
        $uname = $_POST['username'];
        $password = $_POST['psw'];
        $rpassword = $_POST['psw-repeat'];
        $code = $_POST['companyCode'];
        $company = $_POST['companyName'];
        $masterUser = "YES";
        $employeeUser = "NO";

        //when the click on the sign up button
        if(isset($_POST["signup"])){
            
            //check the account table to see if thier any matching emails or username
            $matchEmail = "SELECT * FROM accounts WHERE email LIKE '%$email%'";
            $matchUsername = "SELECT * FROM accounts WHERE username LIKE '%$uname%'";      
            $resultsEmail = mysqli_query($conn, $matchEmail);
            $resultsUsername = mysqli_query($conn, $matchUsername);
            $foundEmail = mysqli_num_rows($resultsEmail);
            $foundUsername = mysqli_num_rows($resultsUsername);
            
            //checks the email, username, and also makes sure the password meet the rules
            if($foundEmail != 0){
                echo "<div class=\"error\">This email account is currently in the system! Please use a new.</div>";
            }else if($foundUsername != 0){
                echo "<div class=\"error\">This username account is currently in the system! Please use a new.</div>";
            }else if(strlen($password) < 7 ){
                echo "<div class=\"error\">Password to short! Please make password 8 characters long or more.</div>";
            }else if($password != $rpassword){
                echo "<div class=\"error\">Passwords do not match! Please retype passwords to match.</div>";
            }else{
                //if user selects current employee
                if(isset($_POST['check']) && $_POST['check'] == 'ce') {
                    $match = "SELECT * FROM accounts WHERE code LIKE '%$code%'";   
                    $results = mysqli_query($conn, $match);
                    $found = mysqli_num_rows($results);
                    if($found == 0){
                        echo "<div class=\"error\">There is number does not belong to any company! Please try again.</div>";
                    }else{
                        $match = "SELECT * FROM accounts WHERE code LIKE '%$code%'";   
                        $results = mysqli_query($conn, $match);
                        $run = mysqli_fetch_array($results);
                        $companyName = $run['company_name'];
                        $sql = "INSERT INTO accounts (company_name, password, username, fname, lname, email, code, MU) 
                        VALUES ('$companyName', '$password', '$uname', '$fname', '$lname', '$email', '$code', '$employeeUser')";
                        if(mysqli_query($conn, $sql)){
                            header("Location: index.php");
                            exit();
                        }else{
                        echo "<div class=\"error\">ERROR: Could not able to execute $sql. </div>" . mysqli_error($conn);
                        }
                    }
                //if user selectes new company 
                }else if(isset($_POST['check']) && $_POST['check'] == 'nc'){
                    $randCode = rand(0, 9999);
                    do{
                        $match = "SELECT * FROM accounts WHERE code LIKE '%$randCode%'";   
                        $results = mysqli_query($conn, $match);
                        $found = mysqli_num_rows($results);
                        if($found != 0){
                            $randCode = rand(0, 9999);
                        }
                    }while($found != 0);
                    $sql = "INSERT INTO accounts (company_name, password, username, fname, lname, email, code, MU) 
                    VALUES ('$company', '$password', '$uname', '$fname', '$lname', '$email', '$randCode','$masterUser')";
                    if(mysqli_query($conn, $sql)){
                        $sql = "CREATE TABLE `$company` (
                            id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                            priority VARCHAR(10) NOT NULL,
                            job_title VARCHAR(50) NOT NULL,
                            customer VARCHAR(50) NOT NULL,
                            payment VARCHAR(50) NOT NULL,
                            progress VARCHAR(20) NOT NULL,
                            phone_number VARCHAR(15) NOT NULL,
                            startDate DATE NOT NULL,
                            endDate DATE NOT NULL,
                            reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                            )";
                            if ($conn->query($sql) === TRUE) {
                                echo "Table MyGuests created successfully";
                              } else {
                                echo "Error creating table: " . $conn->error;
                              }
                            header("Location: index.php");
                            exit();
                    }else{
                        echo "<div class=\"error\">ERROR: Could not able to execute $sql. </div>" . mysqli_error($conn);
                    }
                }else{
                    echo "<div class=\"error\">Please select one of the check boxes.</div>";
                } 
            }
        }
    ?>
</body>
</html>
